<!DOCTYPE html>

<html>
<head>
	<!-- BEGIN META SECTION -->
    <title>Contact</title>	
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0,user-scalable=no">
	<meta content="financial, barometer, money, manage money, income, consumption, statistics, categorize" name = "keywords" /> 
    <meta content="Manage your income and consumption. View statistics of your money deviation through out the year." name="description" />
    <meta content="Yuliyan Shinovski" name="author" />
    <link rel="shortcut icon" href="assets/img/favicon.png">
    <!-- END META SECTION -->
    <!-- BEGIN STYLE -->
	<link href='http://fonts.googleapis.com/css?family=Montserrat:700,400' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="assets/css/custom.css">
    <!-- END STYLE -->
</head>
<body>

<div class="wrapper">
	<div id="menu">
		<ul>
			<li><a href="home.php">Home</a></li>
			<li><a class="active" href="contact.php">Contact</a></li>
			<ul style="float:right;list-style-type:none;">
				<li><a href="register.php">Register</a></li>
				<li><a href="login.php">Login</a></li>
			</ul>
		</ul>
	</div>

	<div id="contact">
		<h1>Контакти</h1>
		<p>При проблем или други въпроси моля свържете се с нас на: <a href="http://www.google.com">FBarometer.org</a>,<br>или чрез:</p> 
		<ul>
			<li>Телефон за контакт: 0889123456</li>
			<li>e-mail: <a href="http://www.google.com">FBarometer@gmail.com</a></li>
			<li>skype: <a href="http://www.google.com">TopCoder</a>
		</ul>
	</div>
	
	<div id="footer">
	<?php
		echo "<p>Copyright &copy; 2016-" . date("Y") . " FBarometer.com All Rights Reserved</p>";
	?>
	</div>
</div>

</body>
</html> 