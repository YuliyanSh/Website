--
-- Database: `fbarometer`
--

-- --------------------------------------------------------

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`ID`, `Name`, `Type`, `Category`, `Amount`, `Date`) VALUES
(1, 'Yuliyan Shinovski', 'profit', 'salary', 3000, '2016-01-28'),
(7, 'Yuliyan Shinovski', 'expense', 'rent', 80, '2016-02-24'),
(8, 'Yuliyan Shinovski', 'expense', 'clothes', 120, '2016-01-29'),
(9, 'Yuliyan Shinovski', 'expense', 'rent', 80, '2016-01-29'),
(15, 'Ivan Petkov', 'profit', 'gamble', 25, '2016-02-06'),
(16, 'Ivan Petkov', 'profit', 'gamble', 50, '2016-02-05');

-- --------------------------------------------------------

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `Name`, `password`, `email`) VALUES
(1, 'Yuliyan Shinovski', 'sparta', 'yuliyan_sh@abv.bg'),
(5, 'Ivan Petkov', 'firefly', 'ivan@abv.bg');