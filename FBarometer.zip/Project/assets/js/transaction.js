function setCategory(){
    var el = document.getElementById("profitType");
	var el2 = document.getElementById("expenseType");
    if(el.checked) {
		uncheck();
		var elements = document.getElementsByClassName("profit");
		var len = elements.length
		for (var i = 0; i < elements.length; i++) {
			document.getElementsByClassName("profit")[i].disabled = false;
		}
	}
    else {
		uncheck();
		var elements = document.getElementsByClassName("profit");
		var len = elements.length
		for (var i = 0; i < elements.length; i++) {
			document.getElementsByClassName("profit")[i].disabled = true;
		}
	}
	if(el2.checked) {
		uncheck();
		var elements = document.getElementsByClassName("expense");
		var len = elements.length
		for (var i = 0; i < elements.length; i++) {
			document.getElementsByClassName("expense")[i].disabled = false;
		}
	}
    else {
		uncheck();
		var elements = document.getElementsByClassName("expense");
		var len = elements.length
		for (var i = 0; i < elements.length; i++) {
			document.getElementsByClassName("expense")[i].disabled = true;
		}
	}
  }

function uncheck() {
	var allRadios = document.getElementsByName('inputCategory');
    for(var i = 0; i < allRadios.length; i++) {
		if (allRadios[i].checked) {
			allRadios[i].checked = false;
		}
    }
}		