<?php
	// Prevent manual redirection to the php files behind login validation.
	// Start the session
	session_start();
	if (empty($_SESSION["username"])) {
		// not in session
		header('Location: home.php');
	}
?>
<!DOCTYPE html>

<html>
<head>
	<!-- BEGIN META SECTION -->
    <title>Transaction</title>	
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0,user-scalable=no">
	<meta content="financial, barometer, money, manage money, income, consumption, statistics, categorize" name = "keywords" /> 
    <meta content="Manage your income and consumption. View statistics of your money deviation through out the year." name="description" />
    <meta content="Yuliyan Shinovski" name="author" />
    <link rel="shortcut icon" href="assets/img/favicon.png">
    <!-- END META SECTION -->
    <!-- BEGIN STYLE -->
	<link href='http://fonts.googleapis.com/css?family=Montserrat:700,400' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="assets/css/custom.css">
    <!-- END STYLE -->
</head>
<body>

<div class="wrapper">
	<div id="menu">
		<ul>
			<li><a class="active" href="transactions.php">Transaction</a></li>
			<li><a href="balance.php">Balance</a></li>
			<li><a href="statistics.php">Statistics</a></li>
			<ul style="float:right;list-style-type:none;">
				<li><a href="home.php">Logout</a></li>
			</ul>
		</ul>
	</div>

	<div id="transactions">
		<h2>Add a new transaction</h2>
		<form id="transactionForm" method="post" action="add.php">
			<span style="font-weight: bold">Type:</span> 
						<input type="radio" name="inputType" id="profitType" value="profit" onchange="setCategory();">Profit
						<input type="radio" name="inputType" id="expenseType" value="expense" onchange="setCategory();">Expense<br>
			<span style="font-weight: bold">Category:</span> 
						<input type="radio" name="inputCategory" class="profit" value="salary" disabled="disabled">Salary
						<input type="radio" name="inputCategory" class="profit" value="scholarship" disabled="disabled">Scholarship
						<input type="radio" name="inputCategory" class="profit" value="heritage" disabled="disabled">Heritage
						<input type="radio" name="inputCategory" class="profit" value="gamble" disabled="disabled">Gamble<br>
						<input type="radio" name="inputCategory" class="expense" value="food" disabled="disabled">Food
						<input type="radio" name="inputCategory" class="expense" value="fuel" disabled="disabled">Fuel
						<input type="radio" name="inputCategory" class="expense" value="rent" disabled="disabled">Rent
						<input type="radio" name="inputCategory" class="expense" value="utilities" disabled="disabled">Utilities
						<input type="radio" name="inputCategory" class="expense" value="clothes" disabled="disabled">Clothes
						<input type="radio" name="inputCategory" class="expense" value="other" disabled="disabled">Other<br>
			<span style="font-weight: bold">Amount:</span> 
						<input type="text" name="inputAmount"><br>
			<span style="font-weight: bold">Date:</span> 
						<input type="text" name="inputDate"><br>
			<input type="submit" name="submit" value="Add">
		</form>
	</div>
	
	<div id="footer">
	<?php
		echo "<p>Copyright &copy; 2016-" . date("Y") . " FBarometer.com All Rights Reserved</p>";
	?>
	</div>
</div>

<script src="assets/js/transaction.js"></script>

</body>
</html> 