<?php

class Transaction {
	private $ID;
	private $Name;
	private $Type;
	private $Category;
	private $Date;
	
	function getId()
	{
		return $this->ID;
	}
	
	function setId($ID)
	{
		$this->ID = $ID;
	}
	
	function getName()
	{
		return $this->Name;
	}
	
	function setName($Name)
	{	
		$this->Name = $Name;
	}
	
	function getType()
	{
		return $this->Type;
	}
	
	function setType($Type)
	{
		$this->Type = $Type;
	}
	
	function getCategory()
	{
		return $this->Category;
	}
	
	function setCategory($Category)
	{
		$this->Category = $Category;
	}
	
	function getAmount()
	{
		return $this->Amount;
	}
	
	function setAmount($Amount)
	{
		$this->Amount = $Amount;
	}
	
	function getDate()
	{
		return $this->Date;
	}
	
	function setDate($Date)
	{
		$this->Date = $Date;
	}
	
	public function __toString() 
	{
		return sprintf('<pre>%s</pre>', var_dump($this));
	}
}
?>