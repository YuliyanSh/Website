<?php

	// Start the session
	session_start();
	
	// Connect to DB
	require_once('DB.php');
	require_once('User.php');
	
	$name = $_POST['inputName'];
	$password = $_POST['inputPassword'];
	$email = $_POST['inputEmail'];
	
	// Set session variables
    $_SESSION["username"] = $name;
	
	if(empty($_POST['inputName']) || empty($_POST['inputPassword']) || empty($_POST['inputEmail'])) {
		// form not filled, return to registration form
		header('Location: register.php');
	} else {
		try {
				$db = DB::getInstance();
				$stmt = $db->query("select * from users where Name='$name'");
				$stmt->setFetchMode(PDO::FETCH_CLASS, 'User');

				if ($user = $stmt->fetch()) {
					// name already in use, return to registration form
					header('Location: register.php');
				} else {
					// create new record in db and redirect to transactions
					$db->query("INSERT INTO users ( Id, Name, password, email ) VALUES ( NULL, '$name', '$password', '$email' )");
					header('Location: transactions.php');
				}
			} catch (Exception $e) {
				print $e->getMessage();
				}
	}
?>