<?php
	// Start the session
	session_start();
	
	// remove all session variables
	session_unset();

	// destroy the session
	session_destroy();
?>

<!DOCTYPE html>

<html>
<head>
	<!-- BEGIN META SECTION -->
    <title>Financial Barometer</title>	
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0,user-scalable=no">
	<meta content="financial, barometer, money, manage money, income, consumption, statistics, categorize" name = "keywords" /> 
    <meta content="Manage your income and consumption. View statistics of your money deviation through out the year." name="description" />
    <meta content="Yuliyan Shinovski" name="author" />
    <link rel="shortcut icon" href="assets/img/favicon.png">
    <!-- END META SECTION -->
    <!-- BEGIN STYLE -->
	<link href='http://fonts.googleapis.com/css?family=Montserrat:700,400' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="assets/css/custom.css">
    <!-- END STYLE -->
</head>
<body>

<div class="wrapper">
	<div id="menu">
		<ul>
			<li><a class="active" href="home.php">Home</a></li>
			<li><a href="contact.php">Contact</a></li>
			<ul style="float:right;list-style-type:none;">
				<li><a href="register.php">Register</a></li>
				<li><a href="login.php">Login</a></li>
			</ul>
		</ul>
	</div>

	<div id="home">
		<h1>Какво е финансов барометър?</h1>
		<p>Финансов барометър е система за отчет на доходите на съответния потребител. Тя предлага лесен и удобен начин за:</p>
		<ul>
			<li>Въвеждане на приходи/разходи по категории.</li>
			<li>Oтчет на дневен, седмичен, месечен и годишен баланс.</li>
			<li>Водене на статистики за разходите по категории.</li>
		</ul>
	</div>
	
	<div id="footer">
	<?php
		echo "<p>Copyright &copy; 2016-" . date("Y") . " FBarometer.com All Rights Reserved</p>";
	?>
	</div>
</div>

</body>
</html> 