<?php
require_once('config.php');

class DB {

    // Declare instance
    private static $_db = NULL;

    /**
     * Protected constructor to prevent creating a new instance of the
     * *Singleton* via the `new` operator from outside of this class.
     */
    protected function __construct()
    {
    }

    /**
     * Private clone method to prevent cloning of the instance of the
     * *Singleton* instance.
     *
     * @return void
     */
    private function __clone()
    {
    }

    /**
     * Private unserialize method to prevent unserializing of the *Singleton*
     * instance.
     *
     * @return void
     */
    private function __wakeup()
    {
    }
    /**
    * Return DB instance or create intitial connection
    *
    * @return object (PDO)
    * @access public
    */
    public static function getInstance() {
        if (!self::$_db) {
            self::$_db = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USERNAME, DB_PASSWORD);
            self::$_db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        return self::$_db;
    }

    public function __call ($method, $args) {
        self::getInstance();
        if ( is_callable(array(self::$_db, $method)) ) {
            return call_user_func_array(array(self::$_db, $method), $args);
        }
        else {
            throw new BadMethodCallException('Undefined method DB::' . $method);
        }
    }

}

?>