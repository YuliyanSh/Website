<?php
	// Connect to DB
	require_once('DB.php');
	require_once('Transaction.php');
	
	// name
	$name = $_SESSION["username"];
	// today
	$dateDay = date("Y-m-d");
	// start of the week
	$day = date('w');
	if ($day == 0) {$day=7;}
	$day -= 1;
	$dateWeekStart = date('Y-m-d', strtotime('-'.$day.' days'));
	// start of the month
	$dateMonthStart = date('Y-m-01');
	// start of the year
	$dateYearStart = date('Y-01-01');
	
	if (empty($_SESSION["username"])) {
		// send back to home
		header('Location: home.php');
	} else {
		try {
				$db = DB::getInstance();
				
				// Daily
				$stmtD = $db->query("select Type, Amount from transactions where Name='$name' and Date='$dateDay'");
				$stmtD->setFetchMode(PDO::FETCH_CLASS, 'Transaction');
				
				$counterProfitD = 0;$counterExpenseD = 0;
				while ($transaction = $stmtD->fetch()) {
					switch ($transaction->getType()) {
						case "profit":
							$counterProfitD += $transaction->getAmount();
							break;
						case "expense":
							$counterExpenseD += $transaction->getAmount();
							break;
					}
				}
				
				// Weekly
				$stmtW = $db->query("select Type, Amount from transactions where Name='$name' and Date BETWEEN '$dateWeekStart' and '$dateDay'");
				$stmtW->setFetchMode(PDO::FETCH_CLASS, 'Transaction');
				
				$counterProfitW = 0;$counterExpenseW = 0;
				while ($transaction = $stmtW->fetch()) {
					switch ($transaction->getType()) {
						case "profit":
							$counterProfitW += $transaction->getAmount();
							break;
						case "expense":
							$counterExpenseW += $transaction->getAmount();
							break;
					}
				}
				
				// Monthly
				$stmtM = $db->query("select Type, Amount from transactions where Name='$name' and Date BETWEEN '$dateMonthStart' and '$dateDay'");
				$stmtM->setFetchMode(PDO::FETCH_CLASS, 'Transaction');
				
				$counterProfitM = 0;$counterExpenseM = 0;
				while ($transaction = $stmtM->fetch()) {
					switch ($transaction->getType()) {
						case "profit":
							$counterProfitM += $transaction->getAmount();
							break;
						case "expense":
							$counterExpenseM += $transaction->getAmount();
							break;
					}
				}
				
				// Annual
				$stmtA = $db->query("select Type, Amount from transactions where Name='$name' and Date BETWEEN '$dateYearStart' and '$dateDay'");
				$stmtA->setFetchMode(PDO::FETCH_CLASS, 'Transaction');
				
				$counterProfitA = 0;$counterExpenseA = 0;
				while ($transaction = $stmtA->fetch()) {
					switch ($transaction->getType()) {
						case "profit":
							$counterProfitA += $transaction->getAmount();
							break;
						case "expense":
							$counterExpenseA += $transaction->getAmount();
							break;
					}
				}
				
				echo "<tr>
						<td>Profit</td><td>" . $counterProfitD . "лв</td><td>" . $counterProfitW . "лв</td>
						<td>" . $counterProfitM . "лв</td><td>" . $counterProfitA . "лв</td>
					</tr>
					<tr>
						<td>Expense</td><td>" . $counterExpenseD . "лв</td><td>" . $counterExpenseW . "лв</td>
						<td>" . $counterExpenseM . "лв</td><td>" . $counterExpenseA . "лв</td>
					</tr>
					<tr>
						<td>Balance</td><td>" . ($counterProfitD-$counterExpenseD) . "лв</td><td>" . ($counterProfitW-$counterExpenseW) . "лв</td>
						<td>" . ($counterProfitM-$counterExpenseM) . "лв</td><td>" . ($counterProfitA-$counterExpenseA) . "лв</td>
					</tr>";
			} catch (Exception $e) {
				print $e->getMessage();
				}
	}
?>