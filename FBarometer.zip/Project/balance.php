<?php
	// Prevent manual redirection to the php files behind login validation.
	// Start the session
	session_start();
	if (empty($_SESSION["username"])) {
		// not in session
		header('Location: home.php');
	}
?>
<!DOCTYPE html>

<html>
<head>
	<!-- BEGIN META SECTION -->
    <title>Transaction</title>	
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0,user-scalable=no">
	<meta content="financial, barometer, money, manage money, income, consumption, statistics, categorize" name = "keywords" /> 
    <meta content="Manage your income and consumption. View statistics of your money deviation through out the year." name="description" />
    <meta content="Yuliyan Shinovski" name="author" />
    <link rel="shortcut icon" href="assets/img/favicon.png">
    <!-- END META SECTION -->
    <!-- BEGIN STYLE -->
	<link href='http://fonts.googleapis.com/css?family=Montserrat:700,400' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="assets/css/custom.css">
    <!-- END STYLE -->
</head>
<body>

<div class="wrapper">
	<div id="menu">
		<ul>
			<li><a href="transactions.php">Transaction</a></li>
			<li><a class="active" href="balance.php">Balance</a></li>
			<li><a href="statistics.php">Statistics</a></li>
			<ul style="float:right;list-style-type:none;">
				<li><a href="home.php">Logout</a></li>
			</ul>
		</ul>
	</div>

	<div id="balanceTable">
		<h2>Balance</h2>
		 <table id="balance">
			 <tr>
				<th><img src="assets/img/scale.png" alt="scale" style="width:50px;height:50px;"></th>
				<th>Daily</th>
				<th>Weekly</th>
				<th>Monthly</th>
				<th>Annual</th>
			 </tr>
			 <?php require_once('getBalance.php'); ?>
		</table> 
	</div>
	
	<div id="footer">
	<?php
		echo "<p>Copyright &copy; 2016-" . date("Y") . " FBarometer.com All Rights Reserved</p>";
	?>
	</div>
</div>

</body>
</html> 