<?php
	// Connect to DB
	require_once('DB.php');
	require_once('Transaction.php');
	
	$name = $_SESSION["username"];
	
	if (empty($_SESSION["username"])) {
		// send back to home
		header('Location: home.php');
	} else {
		try {
				$db = DB::getInstance();
				$stmt = $db->query("select Category, Amount from transactions where Name='$name' and Type='expense'");
				$stmt->setFetchMode(PDO::FETCH_CLASS, 'Transaction');
				
				$counter1 = 0;$counter2 = 0;$counter3 = 0;$counter4 = 0;$counter5 = 0;$counter6 = 0;
				while ($transaction = $stmt->fetch()) {
					switch ($transaction->getCategory()) {
						case "food":
							$counter1 += $transaction->getAmount();
							break;
						case "fuel":
							$counter2 += $transaction->getAmount();
							break;
						case "rent":
							$counter3 += $transaction->getAmount();
							break;
						case "utilities":
							$counter4 += $transaction->getAmount();
							break;
						case "clothes":
							$counter5 += $transaction->getAmount();
							break;
						case "other":
							$counter6 += $transaction->getAmount();
							break;
						default:
							echo "Wrong category<br>";
					}
				}
				echo "<td>" . $counter1 . "лв</td><td>" . $counter2 . "лв</td><td>" . $counter3 . "лв</td>
					  <td>" . $counter4 . "лв</td><td>" . $counter5 . "лв</td><td>" . $counter6 . "лв</td>";
			} catch (Exception $e) {
				print $e->getMessage();
				}
	}
?>