<?php

	// Start the session
	session_start();
	
	// Connect to DB
	require_once('DB.php');
	require_once('User.php');
	
	$name = $_POST['inputName'];
	$password = $_POST['inputPassword'];
	
	// Set session variables
    $_SESSION["username"] = $name;
	
	if(empty($_POST['inputName']) || empty($_POST['inputPassword'])) {
		// form not filled, return to login form
		header('Location: login.php');
	} else {
		try {
				$db = DB::getInstance();
				$stmt = $db->query("select * from users where Name='$name' and password='$password'");
				$stmt->setFetchMode(PDO::FETCH_CLASS, 'User');

				if ($user = $stmt->fetch()) {
					// login succesfull, redirect to transactions
					header('Location: transactions.php');
				} else {
					// wrong name or password, return to login form
					header('Location: login.php');
					}
			} catch (Exception $e) {
				print $e->getMessage();
				}
	}
?>