<?php

	// Start the session
	session_start();
	
	// Connect to DB
	require_once('DB.php');
	require_once('Transaction.php');
	
	$name = $_SESSION["username"];
	$type = $_POST['inputType'];
	$category = $_POST['inputCategory'];
	$amount = $_POST['inputAmount'];
	$date = $_POST['inputDate'];
	$date = date("Y/m/d", strtotime($date));
	
	if (empty($_SESSION["username"]) || empty($_POST['inputType']) || empty($_POST['inputCategory']) ||
	    empty($_POST['inputAmount']) || empty($_POST['inputDate'])) {
		// form not filled, return to transactions form
		header('Location: transactions.php');
	} else {
		try {
				$db = DB::getInstance();
				$db->query("INSERT INTO transactions ( Id, Name, Type, Category, Amount, Date ) 
				            VALUES ( NULL, '$name', '$type', '$category', '$amount', '$date' )");
				header('Location: transactions.php');		
			} catch (Exception $e) {
				print $e->getMessage();
				}
	}
?>