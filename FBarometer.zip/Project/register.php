<!DOCTYPE html>

<html>
<head>
	<!-- BEGIN META SECTION -->
    <title>Register</title>	
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0,user-scalable=no">
	<meta content="financial, barometer, money, manage money, income, consumption, statistics, categorize" name = "keywords" /> 
    <meta content="Manage your income and consumption. View statistics of your money deviation through out the year." name="description" />
    <meta content="Yuliyan Shinovski" name="author" />
    <link rel="shortcut icon" href="assets/img/favicon.png">
    <!-- END META SECTION -->
    <!-- BEGIN STYLE -->
	<link href='http://fonts.googleapis.com/css?family=Montserrat:700,400' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="assets/css/custom.css">
    <!-- END STYLE -->
</head>
<body>

<div class="wrapper">
	<div id="menu">
		<ul>
			<li><a href="home.php">Home</a></li>
			<li><a href="contact.php">Contact</a></li>
			<ul style="float:right;list-style-type:none;">
				<li><a class="active" href="register.php">Register</a></li>
				<li><a href="login.php">Login</a></li>
			</ul>
		</ul>
	</div>
	
	
	
	<div id="register">
		

		<h2>Registration for Financial Barometer</h2>
		<form method="post" action="create.php">
			Name: <input type="text" name="inputName" value="">
			<br><br>
			E-mail: <input type="text" name="inputEmail" value="">
			<br><br>
			Password: <input type="password" name="inputPassword" value="">
			<br><br>
			<input type="submit" name="submit" value="Register">
		</form>
	</div>
	
	<div id="footer">
	<?php
		echo "<p>Copyright &copy; 2016-" . date("Y") . " FBarometer.com All Rights Reserved</p>";
	?>
	</div>
</div>

</body>
</html> 